/*
Complete this file header...
Name: David Zheng
NetID: dz183
Purpose: This is for the parse declarations 
*/

extern int nextToken;

// Function forward declarations
int lex();
void sentence();

